/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */
#ifndef _CONFIG_H_
#define _CONFIG_H_

#define DLL_NAME "libproxychains4.so"

typedef in_port_t uint16_t
